let elList=document.querySelector('.list');
let data=[];

function renderTodos(arr, node) {
   node.innerHTML=null;
   
   let fragmentTodos=document.createDocumentFragment();

   arr.forEach(element=>{
      let newLi=document.createElement('li');
      let newId=document.createElement('p');
      let newName=document.createElement('p');
      let newUsername=document.createElement('p');
      let newEmail=document.createElement('p');
      let newAddress=document.createElement('p');
      let newAddressList=document.createElement('ul');
      let newPhone=document.createElement('p');
      let newWebsite=document.createElement('p');
      let newCompany=document.createElement('p');
      let newCompanyList=document.createElement('ul');

      newId.textContent=element.id;
      newName.textContent=element.name;
      newUsername.textContent=element.username;
      newEmail.textContent=element.email;
      newAddress.textContent='Address';
         {
         let newStreet=document.createElement('li');
         let newSuite=document.createElement('li');
         let newCity=document.createElement('li');
         let newZipcode=document.createElement('li');
         let newGeo=document.createElement('li');
         let newGeoList=document.createElement('ul');

         newStreet.textContent=element.address.street;
         newSuite.textContent=element.address.suite;
         newCity.textContent=element.address.city;
         newZipcode.textContent=element.address.zipcode;
         newGeo.textContent='Geo';
         {
            let newLat=document.createElement('li');
            let newLng=document.createElement('li');

            newLat.textContent=element.address.geo.lat;
            newLng.textContent=element.address.geo.lng;

            newGeoList.appendChild(newLat);
            newGeoList.appendChild(newLng);
         }
         
         newAddressList.appendChild(newStreet);
         newAddressList.appendChild(newSuite);
         newAddressList.appendChild(newCity);
         newAddressList.appendChild(newZipcode);
         newAddressList.appendChild(newGeo);
         newAddressList.appendChild(newGeoList);
         }
      newPhone.textContent=element.phone;
      newWebsite.textContent=element.website;
      newCompany.textContent='Company';
      {
         let newCompanyName=document.createElement('li');
         let newCatchPhrase=document.createElement('li');
         let newBs=document.createElement('li');

         newCompanyName.textContent=element.company.name;
         newCatchPhrase.textContent=element.company.catchPhrase;
         newBs.textContent=element.company.bs;

         newCompanyList.appendChild(newCompanyName);
         newCompanyList.appendChild(newCatchPhrase);
         newCompanyList.appendChild(newBs);
      }

      newLi.appendChild(newId);
      newLi.appendChild(newName);
      newLi.appendChild(newUsername);
      newLi.appendChild(newEmail);
      newLi.appendChild(newAddress);
      newLi.appendChild(newAddressList);
      newLi.appendChild(newPhone);
      newLi.appendChild(newWebsite);
      newLi.appendChild(newCompany);
      newLi.appendChild(newCompanyList);

      fragmentTodos.appendChild(newLi);
   });
   node.appendChild(fragmentTodos);
}

fetch('https://jsonplaceholder.typicode.com/users').then(res=> res.json()).then(data=>renderTodos(data, elList));
